package controllers;

import application.Carrito;
import application.LibreriaBd;
import application.Libro;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/** Controlador para la intefaz de carrito.
 */

public class CarritoControler {
  @FXML
  private Label cantidadLibros;
 
  @FXML
  private TableColumn<Libro, HBox> columnaAcciones;

  @FXML
  private TableColumn<Libro, Integer> columnaCantidad;

  @FXML
  private TableColumn<Libro, String> columnaLibro;

  @FXML
  private TableColumn<Libro, Double> columnaPrecio;

  @FXML
  private TableColumn<Libro, Double> columnaTotal;

  @FXML
  private ImageView img1;

  @FXML
  private ImageView img2;

  @FXML
  private ImageView img3;

  @FXML
  private Label labelIva;

  @FXML
  private Label labelSubTotal;

  @FXML
  private Label labelTotal;

  @FXML
  private TableView<Libro> tablaCarrito;
  
  private LibreriaBd bd;
  
  private int stock;
  
  private int cantidad;
  
  @FXML
  private VBox rootPane;
  
  private LibreriaBd baseD = new LibreriaBd();
  
  private Carrito carrito;  // Referencia al carrito para obtener la cantidad y calcular el total
  
  private ObservableList<Libro> librosEnCarrito = FXCollections.observableArrayList();
  /** Metodo para pasar la listda de libros de una interfa a otra.
  */
  
  public void setCarrito(Carrito carr, LibreriaBd libreria) {
    this.bd = libreria;
    this.carrito = carr;
    librosEnCarrito.addAll(carr.getLibrosEnCarrito());
    tablaCarrito.setItems(librosEnCarrito);
    configurarInicio();
  }
  /** Configurar todo.
   */
  
  public void configurarInicio() {
    // Configura las columnas de la interfaz, probablemente para una tabla o lista
    configurarColumnas();
    // Calcula el total de los artículos en el carrito
    double total = carrito.calcularTotal();
    // Calcula el IVA (16% del total)   
    double iva = carrito.calcularTotal() * 0.16;
    // Actualiza el texto del label que muestra el subtotal con el total calculado
    labelSubTotal.setText("$" + total);
    // Actualiza el texto del label que muestra el IVA con el valor calculado
    labelIva.setText("$" + iva);
    // Actualiza el texto del label que muestra el total (subtotal + IVA)
    labelTotal.setText("$" + (total + iva));
    // Actualiza el texto que muestra la cantidad total de libros en el carrito
    cantidadLibros.setText(carrito.obtenerTotalLibros() + " pz.");
  }
  /* Metodo para configurar las columnas de la tabla
   */
  
  private void configurarColumnas() {
    // Configura la columna que muestra el titulo y autor del libro
    columnaLibro.setCellValueFactory(data -> {
      // Devuelve una propiedad de cadena que combina el titulo y el autor
      return new SimpleStringProperty(data.getValue().getTitulo()
       + "\nDe:" + data.getValue().getAutor());
    });
    // Configura la columna que muestra la cantidad de cada libro en el carrito
    columnaCantidad.setCellValueFactory(data -> {
      // Obtiene la cantidad del libro en el carrito
      int cantidad = carrito.getCantidadLibro(data.getValue());
      // Devuelve la cantidad como una propiedad entera
      return new SimpleIntegerProperty(cantidad).asObject();
    });
    // Configura la columna que muestra el precio del libro
    columnaPrecio.setCellValueFactory(data -> {
      // Devuelve el precio como una propiedad de tipo donlr
      return new SimpleDoubleProperty(data.getValue().getPrecio()).asObject();
    });
    // Configura la columna que muestra ek tital del libro (Precio * cantidad)
    columnaTotal.setCellValueFactory(data -> {
      // Obtiene la cantidad del libro en el carrito
      int cantidad = carrito.getCantidadLibro(data.getValue());
      // Calcula el total multiplicando el precio por la cantidad
      double total = data.getValue().getPrecio() * cantidad;
      // Devuelve el total como una propiedad de tipo doble
      return new SimpleDoubleProperty(total).asObject();
    });
    // Configura para acciones
    configurarColumnaAcciones();
  }
  /* Metodo para configurar las columnas de acciones
   */
  
  private void configurarColumnaAcciones() {
    //Configuracion de la columna acciones para cada libro en la tabla
    columnaAcciones.setCellFactory(columnaAcciones -> {
      return new TableCell<Libro, HBox>() {
        // Botones para aumentar, disminuir cantidad y eliminar libro
        private final Button btnAumentar = new Button("+");
        private final Button btnDisminuir = new Button("-");
        private final Button btnEliminar = new Button("Eliminar");
        // Contenedore HBox para los botones
        private final HBox hbox = new HBox(10, btnAumentar, btnDisminuir, btnEliminar); {
          // Aplico la clase de estilo que tengo para todos lo votones
          btnAumentar.getStyleClass().add("bottones2");
          btnDisminuir.getStyleClass().add("bottones2");
          btnEliminar.getStyleClass().add("bottones2");
          
          //Accion que se ejecuta al hacer click en el boton aumentar
          btnAumentar.setOnAction(eventHandler -> {
            
            // Obtine el libro de la fila
            Libro lib = getTableView().getItems().get(getIndex());
            try {
              stock = bd.obtenerStock(lib);
              cantidad = carrito.getCantidadLibro(lib);
              if ((stock - cantidad) != 0) {
                carrito.agregarLibro(lib); // Aumenta la cantidad del libro
                baseD.actualizarCantCarrito(carrito.getIdCarrito(), lib.getIdLibro(), 1);
                lib.setStock(lib.getStock() - 1);
                configurarInicio(); // Actualiza la interfaz  
              } else {
                Alert alert = new Alert(AlertType.ERROR, "No hay stock suficiente");
                alert.showAndWait();  
              }
            } catch (Exception e) {
              // TODO: handle exception
              e.printStackTrace();
            }
          });
          // Accion que se ejecuta al hacer click en el boton de disminuir
          btnDisminuir.setOnAction(eventHandler -> {
            Libro lib = getTableView().getItems().get(getIndex()); // Obtiene el libro de la fila
            // Verifica si la cantidad es mator que uno, para poder eliminar solo una caintdiad
            if (carrito.getCantidadLibro(lib) > 1) {
              carrito.eliminarCantidad(lib); // Disminuye la cantidad del libro
              try {
                baseD.actualizarCantCarrito(carrito.getIdCarrito(), lib.getIdLibro(), -1);
              } catch (Exception e) {
                e.printStackTrace();
              }
              configurarInicio(); 
            } else {
              // Manda alerta si el libro se tiene que eliminar del carro por completo
              Alert alert = new Alert(
                  Alert.AlertType.CONFIRMATION, "¿Deseas eliminar el libro de tu carrito?");
              Optional<ButtonType> resultado = alert.showAndWait();
              if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
                try {
                  baseD.eliminarLibro(carrito.getIdCarrito(), lib.getIdLibro());
                } catch (Exception e) {
                  e.printStackTrace();
                }
                carrito.eliminarLibro(lib); // Elimina el libro del carrito
                librosEnCarrito.remove(lib);
                // Si el carrito esta vacio, muestra una alerta y regresa a la lista de libros
                if (carrito.obtenerTotalLibros() == 0) {
                  Alert alerta = new Alert(Alert.AlertType.INFORMATION, 
                      "Carrito vacio, regresando a la lista de libros");
                  alerta.showAndWait();
                  try {
                    navegarListaLibros();
                  } catch (Exception e2) {
                    e2.printStackTrace();
                  }
                } else {
                  configurarInicio(); // Actualiza la interfaz
                }
              }
            }
          });
          // Accion que se ejecuta al hacer click en el boton eliminar
          btnEliminar.setOnAction(eventHandler -> {
            // Pregunta si desea eliminar el libro
            Libro lib = getTableView().getItems().get(getIndex());
            Alert alert = new Alert(
                      Alert.AlertType.CONFIRMATION, "¿Deseas eliminar el libro de tu carrito?");
            Optional<ButtonType> resultado = alert.showAndWait();
            if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
              carrito.eliminarLibro(lib); // Eliminar el libro del carrito
              try {
                baseD.eliminarLibro(carrito.getIdCarrito(), lib.getIdLibro());
              } catch (Exception e) {
                e.printStackTrace();
              }
              librosEnCarrito.remove(lib);
              // Si el carrito esta vacionm, regresa a la interfaz de la lista de libros
              if (carrito.obtenerTotalLibros() == 0) {
                Alert alerta = new Alert(Alert.AlertType.INFORMATION, 
                      "Carrito vacio, regresando a la lista de libros");
                alerta.showAndWait();
                try {
                  navegarListaLibros();
                } catch (IllegalAccessException e) {
                  e.printStackTrace();
                }
              } else {
                configurarInicio(); // Actualiza la interfaz
              }
            }
          });
        }
    
        @Override
    protected void updateItem(HBox item, boolean res) {
          // Llamo al metodo de la superclase para mantener el comportamiento
          super.updateItem(item, res);
          // Es para verificar si la celda esta vacia o no
          if (res) {
            // Si la celda esta vacia, no muestra el hbox
            setGraphic(null);
          } else {
            // si la celda no esta vacia muestro el hbox que contiene los botones
            setGraphic(hbox);
          }
        }
      };
    });
  }
  
  /** Metodo para pasar a hacer el pago.
   */

  @FXML
  public void btnConfirmar(ActionEvent event) throws SQLException {
    double total = (double) carrito.calcularTotal() + (carrito.calcularTotal() * 0.16);
    baseD.hacerCompra(carrito.getIdCarrito(), total);
    try {
      final Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Grafica.fxml"));
      AnchorPane root = loader.load();
      Stage primStage = new Stage();
      Scene scene = new Scene(root, 1500, 800);
      scene.getStylesheets().add(
          getClass().getResource("/fxml/ListaLibros.fxml").toExternalForm());
      primStage.setScene(scene);
      primStage.show();
      stage.close();
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }
  /** Regresar a la interfaz anterior.
   */
  
  private void navegarListaLibros() throws IllegalAccessException {
    try {
      final Stage stage = (Stage) rootPane.getScene().getWindow();
      FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/ListaLibros.fxml"));
      VBox root = loader.load();
      ListaLibroController listaController = loader.getController();
      listaController.setCarrito(carrito);
      Stage primStage = new Stage();
      Scene scene = new Scene(root, 1500, 800);
      scene.getStylesheets().add(
          getClass().getResource("/fxml/application.css").toExternalForm());
      primStage.setScene(scene);
      primStage.show();
      stage.close();
    } catch (IOException e) {
      System.out.println("Error al cargar el archivo FXML: " + e.getMessage());
    }
  }
  /** Metodo para regresar a la interfaz anterior por medio del boton.
   */
  
  @FXML
  public void btnVerLista(ActionEvent event) throws IllegalAccessException {
    navegarListaLibros();
  }
}