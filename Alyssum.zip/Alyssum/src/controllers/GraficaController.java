package controllers;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Map;

import application.LibreriaBd;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.Axis;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
/** Controlador para la grafica.
 * 
 */

public class GraficaController {

  @FXML
  private LineChart<String, Number> grafica;

  @FXML
  private CategoryAxis compras;
    
  @FXML
  private TextField fechaFin;

  @FXML
  private TextField fechaIni;

  @FXML
  private NumberAxis total;
    
  LibreriaBd ventasBd = new LibreriaBd();

  @FXML
  void btnBucarDatos(ActionEvent event) {
    String inicio = fechaIni.getText();
    String fin = fechaFin.getText();
    if (!validarFechas(inicio, fin)) {
      return;
    }
    try {
      Map<String, Double> datos = ventasBd.obtenerVentas(inicio, fin);
      llenarGrafica(datos);
    } catch (Exception e) {
      e.printStackTrace();
      mostrarAlerta("Error", "Ocurrio un problema al consultar lso datos");
    }
  }
  
  private boolean validarFechas(String ini, String fin) {
    if (!esFechaValida(ini) || !esFechaValida(fin)) {
      mostrarAlerta("Error", "Las fechas deben tener el formato "
          + "YYYY-MM-DD y ser validas");
      return false;
    }
    if (ini.isEmpty() || fin.isEmpty()) {
      mostrarAlerta("Error", "Debe ingresar ambas fechas.");
    }
    LocalDate inicio = LocalDate.parse(ini);
    LocalDate fini = LocalDate.parse(fin);
    if (inicio.isAfter(fini)) {
      mostrarAlerta("Error", "La fecha de inicio no puede ser posterior a la fecha fin");
      return false;
    }
    return true;
  }
  
  private boolean esFechaValida(String fecha) {
    try {
      LocalDate.parse(fecha);
      return true;
    } catch (DateTimeParseException e) {
      return false;
    }
  }
  
  private void mostrarAlerta(String titulo, String mensaje) {
    Alert alerta = new Alert(AlertType.ERROR);
    alerta.setTitle(titulo);
    alerta.setHeaderText(null);
    alerta.setContentText(mensaje);
    alerta.showAndWait();
  }
  
  private void llenarGrafica(Map<String, Double> datos) {
    grafica.getData().clear();
    if (datos == null || datos.isEmpty()) {
      System.out.println("No hay datos para mostar en la grafica.");
      return;
    }
    XYChart.Series<String, Number> series = new XYChart.Series<>();
    series.setName("Totales por Fecha");
    for (Map.Entry<String, Double> entry  : datos.entrySet()) {
      if (entry.getValue() != null && entry.getValue() != 0) {
        series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
      }
    }
    if (!series.getData().isEmpty()) {
      grafica.getData().add(series);
    } else {
      System.out.println("Los datos en el mapa no son validos para mostrar");
    }
  }
}