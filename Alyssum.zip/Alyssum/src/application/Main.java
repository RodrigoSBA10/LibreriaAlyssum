package application;

/*
* Clase principal de la aplicación de librería.
* Esta clase se encarga de iniciar la aplicación JavaFX, cargar la interfaz de usuario.
* desde un archivo FXML y mostrar la ventana principal.
*/

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * Clase principal de la aplicación de librería.
 */
public class Main extends Application {
  private static final String fxml = "/fxml/Inicio.fxml";
  private static final String css = "/fxml/application.css";
  private static final int width = 1500;
  private static final int height = 800;
  /** Metodo que se llama al iniciar la aplicacion.
  * primaryStage el escenario pricipal de la aplicacion.
  */
  
  @Override
    public final void start(final Stage primaryStage) {
    try {
      //Cargar el archivo FXML
      StackPane root = 
          FXMLLoader.load(
          getClass().getResource(fxml)); 
      // Crear la escne con el panel raiz y stableceer su tamaño
      Scene scene = new Scene(root, width, height); 
      scene.getStylesheets().add(getClass().getResource(css).toExternalForm());
      primaryStage.setScene(scene); //Configurar el escenario y mostrar la ventana
      primaryStage.setTitle("Bienvenidos"); //Titulo de la ventana
      primaryStage.show(); //Muestra la ventana
    } catch (Exception e) {
      System.err.println("Error al cargar la interfaz: " + e.getMessage());
      e.printStackTrace();
    }
  }
  /**
  * Metodo principal que inicia la aplicacion.
  * args argumentos de linea de comandos.
  */
  
  public static void main(final String[] args) {
    launch(args); // llamar al metodo launch para iniciar la aplicaion
  }
}