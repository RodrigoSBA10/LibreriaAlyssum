package application;



/*
 * Es la responsable de manejar la lista de libros y que impplementa seializable
 * Autor: Rodrigo Slavador
 * Fecha: 13 de octubre de 2024
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/**
* La clase Libreria gestiona una lista de objetos de tipo Libro.
* Implementa la interfaz Serializable para permitir la serialización
* de la lista de libros.
*/

public class LibreriaBd {
  // Lista de libros que pertenecen a la librería.
  private List<Libro> libros;
  private static final String url = "jdbc:oracle:thin:@//localhost:1521/xe";
  private static final String user = "System";
  private static final String contra = "123456";
  private static final String consultaLibros = 
      "SELECT libro.ID_LIBRO, libro.TITULO, libro.ISBN,"
      + "autor.NOMBRE AS nombre_autor, editorial.NOMBRE AS nombre_editorial, "
      + "categoria.NOMBRE AS nombre_categoria, genero.NOMBRE AS nombre_genero, "
      + "libro.ANIOPUBLICACION, libro.PRECIO, libro.STOCK, libro.DESCRIPCION "
      + "FROM libro "
      + "JOIN editorial ON libro.ID_EDITORIAL = editorial.ID_EDITORIAL "
      + "JOIN autor ON libro.ID_AUTOR = autor.ID_AUTOR "
      + "JOIN genero ON libro.ID_GENERO = genero.ID_GENERO "
      + "JOIN categoria ON libro.ID_CATEGORIA = categoria.ID_CATEGORIA";
  private static final String obtenStock =
          "SELECT STOCK FROM libro WHERE ID_LIBRO = ?";
  private static final String crearCarrito =
          "INSERT INTO Carrito (Estado) VALUES ('Activo')";
  private static final String obtenerIDCarrito =
          "SELECT MAX(ID_Carrito) FROM Carrito";
  private static final String actualizarCantidadLibro =
          "UPDATE Detalle_Carrito set Cantidad = Cantidad + ? "
          + "WHERE ID_CARRITO = ? "
          + "AND ID_LIBRO = ? ";
  private static final String agregarLibroCarrito =
          "INSERT INTO Detalle_Carrito "
          + "(ID_Carrito, ID_LIBRO, Cantidad, PrecioUnitario) "
          + "VALUES (?, ?, ?, ?)";
  private static final String pedido =
          "INSERT INTO Pedido (Total) VALUES (?)";
  private static final String idPedido =
          "SELECT MAX(ID_PEDIDO) FROM Pedido";
  private static final String pedidoDetalles =
          "INSERT INTO Detalle_Pedido (ID_Pedido, titulolibro, Cantidad, PrecioUnitario)"
          + " SELECT ?, l.Titulo, dc.Cantidad, dc.PrecioUnitario"
          + " FROM Detalle_Carrito dc"
          + " INNER JOIN Libro l ON dc.ID_Libro = l.ID_Libro"
          + " WHERE dc.ID_Carrito = ?";
  private static final String actualizaStock =
          "UPDATE Libro SET STOCK = STOCK - ("
          + " SELECT Cantidad FROM Detalle_Carrito dc WHERE dc.ID_Libro = Libro.ID_Libro"
          + " AND dc.ID_Carrito = ? ) WHERE ID_Libro IN "
          + " (SELECT ID_Libro FROM Detalle_Carrito WHERE ID_Carrito = ? )";
  private static final String finalizaCarrito =
          "UPDATE Carrito SET Estado = 'Finalizado' WHERE ID_Carrito = ?";
  private static final String obtenerStock =
          "SELECT Stock FROM Libro WHERE ID_Libro = ?";
  private static final String eliminarLibroCarrito =
          "DELETE FROM Detalle_Carrito WHERE ID_Carrito = ?"
          + "AND ID_Libro = ?";
  private static final String ventaFecha =
          "SELECT TO_CHAR(fechapedido, 'YYYY-MM-DD') AS Fecha,"
          + " SUM(TOTAL) AS Total FROM Pedido WHERE fechapedido" 
          + " BETWEEN TO_DATE(?, 'YYYY-MM-DD') AND"
          + " TO_DATE(?, 'YYYY-MM-DD') GROUP BY"
          + " TO_CHAR(fechapedido, 'YYYY-MM-DD') ORDER BY Fecha";
  /** Constructor de la clase Libreria.
  * Inicializa una nueva lista de libros vacía.
  */
  
  public LibreriaBd() {
    this.libros = new ArrayList<>(); // Inicializa la lista vacía.
  }
  /**
  * Método para obtener la lista de libros de la librería.
  * Retorna una nueva lista de libros para evitar modificaciones directas
  * a la lista original. 
  * return una nueva lista que contiene los libros de la librería
  */
  
  public List<Libro> getLibros() {
    // Retorna una copia de la lista de libros.
    return new ArrayList<>(libros);
  }
  /** Método para cargar libros desde un archivo.
  * Lee un archivo serializado y carga los libros en la lista. 
  * archivo la ruta del archivo de donde se cargan los libros
  * throws SQLException 
  * throws IOException            si ocurre un error durante la lectura del archivo
  * throws ClassNotFoundException si la clase no es encontrada durante la deserialización
  */
  
  public List<Libro> cargarLibros() throws SQLException {
    try (Connection conn = obtenerConexion();
         Statement stmt = conn.createStatement();
         ResultSet resultadoConsulta = stmt.executeQuery(consultaLibros)) {
      while (resultadoConsulta.next()) {
        int idLibro = resultadoConsulta.getInt("ID_LIBRO");
        String titulo = resultadoConsulta.getString("TITULO");
        String isbn = resultadoConsulta.getString("ISBN");
        // Capturamos el nombre del autor
        String nombreAutor  = resultadoConsulta.getString("nombre_autor"); 
        // Capturamos el nombre de la editorial
        String nombreEditorial = resultadoConsulta.getString("nombre_editorial");  
        // Capturamos el nombre de la categoría
        String nombreCategoria = resultadoConsulta.getString("nombre_categoria");
        // Capturamos el nombre del género
        String nombreGenero = resultadoConsulta.getString("nombre_genero");  
        int anioPublicacion = resultadoConsulta.getInt("ANIOPUBLICACION");
        double precio = resultadoConsulta.getDouble("PRECIO");
        int stock = resultadoConsulta.getInt("STOCK");
        String descripcion = resultadoConsulta.getString("DESCRIPCION");
        Libro libro = new Libro(idLibro, titulo, nombreAutor, isbn, nombreEditorial, 
            nombreCategoria, nombreGenero, anioPublicacion, precio, stock, descripcion);
        libros.add(libro);
      }
    }
    return libros;
  }
  /** Metodo para actualizar el stock.
  */
  
  public void actualizarStock(Libro libro, int cantidadVendida) 
      throws SQLException, IllegalAccessException {
    if (libro == null) {
      throw new IllegalAccessException("El libro no puede ser nulo.");
    }
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(actualizaStock)) {
      pstmt.setInt(1, cantidadVendida);
      pstmt.setInt(2, libro.getIdLibro());
      int filasActualizadas = pstmt.executeUpdate();
      if (filasActualizadas > 0) {
        System.out.println("Stock actualizado correctamente");
      } else {
        System.out.println("No se encontro libro");
      }
    }
  }
  /** Metodo para obtener el stock del libro.
   */
  
  public Integer obtenerStock(Libro libro) throws SQLException, IllegalAccessException {
    if (libro == null) {
      throw new IllegalAccessException("El libro no puede ser nulo.");
    }
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(obtenStock)) {
      pstmt.setInt(1, libro.getIdLibro());
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          return rs.getInt("STOCK");
        } else {
          throw new SQLException("No se encontro el libro.");  
        }
      }
    }
  }
  /** Metodo para crear carrito en la base de datos.
   */
  
  public int crearCarrito() throws SQLException, IllegalAccessException {
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(crearCarrito);
         Statement stmt = conn.createStatement()) {
      pstmt.executeUpdate();
      try (ResultSet rs = stmt.executeQuery(obtenerIDCarrito)) {
        if (rs.next()) {
          return rs.getInt(1);
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return -1;
  }
  /** Metodo para actualizar la cantidad de un libro en el carrito de BD.
   */
  
  public void actualizarCantCarrito(int idCarrito, int idLibro, int cantidad) 
      throws SQLException, IllegalAccessException {
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(actualizarCantidadLibro)) {
      pstmt.setInt(1, cantidad);
      pstmt.setInt(2, idCarrito);
      pstmt.setInt(3, idLibro);
      pstmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
  /** Metodo para agregar libro al carrito.
   */
  
  public void agregarLibroCarrito(int idCarrito, Libro lib, int cantidad) 
      throws SQLException, IllegalAccessException {
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(agregarLibroCarrito)) {
      pstmt.setInt(1, idCarrito);
      pstmt.setInt(2, lib.getIdLibro());
      pstmt.setInt(3, cantidad);
      pstmt.setDouble(4, lib.getPrecio());
      pstmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
  /** Metodo para guardar la compra en la base de datos.
   */
  
  public int hacerCompra(int idCarrito, double totalIva) throws SQLException {
    int idPedido = -1;
    try (Connection conn = obtenerConexion();
        PreparedStatement pstmt = conn.prepareStatement(pedido);
        Statement stmt = conn.createStatement()) {
      pstmt.setDouble(1, totalIva);
      pstmt.executeUpdate();
      try (ResultSet rs = stmt.executeQuery(LibreriaBd.idPedido)) {
        if (rs.next()) {
          idPedido = rs.getInt(1);
        }
      }
      try (PreparedStatement stmtDetalles = conn.prepareStatement(pedidoDetalles)) {
        stmtDetalles.setInt(1, idPedido);
        stmtDetalles.setInt(2, idCarrito);
        stmtDetalles.executeUpdate();
      }
      try (PreparedStatement stmtStock = conn.prepareStatement(actualizaStock)) {
        stmtStock.setInt(1, idCarrito);
        stmtStock.setInt(2, idCarrito);
        stmtStock.executeUpdate();
      }
      try (PreparedStatement stmtFin = conn.prepareStatement(finalizaCarrito)) {
        stmtFin.setInt(1, idCarrito);
        stmtFin.executeUpdate();
      }
    } catch (SQLException e) {
      // TODO: handle exception
      e.printStackTrace();
      throw new SQLException("Hubo un problema al procesar la compra", e);
    }
    return idPedido;
  }
  /** Metodo para obtener el stock de un libro.
   */
  
  public int obtenerStocks(Libro lib) throws SQLException, IllegalAccessException {
    int stock = 0;
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(obtenerStock)) {
      pstmt.setInt(1, lib.getIdLibro());
      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          stock = rs.getInt("Stock");
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw new SQLException("Error al obtener el stock del libro", e);
    }
    return stock;
  }
  /** Metodo para Eliminar un librode del carrito.
   */
  
  public void eliminarLibro(int idCarrito, int idLibro) 
      throws SQLException, IllegalAccessException {
    try (Connection conn = obtenerConexion();
         PreparedStatement pstmt = conn.prepareStatement(eliminarLibroCarrito)) {
      pstmt.setInt(1, idCarrito);
      pstmt.setInt(2, idLibro);
      pstmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    }
  }
  /** Metodo para obtener Ventas.
   */
  
  public Map<String, Double> obtenerVentas(String fechaIni, String fechaFin) 
      throws SQLException, IllegalAccessException {
    try (Connection conn = obtenerConexion();
         PreparedStatement stmt = conn.prepareStatement(ventaFecha)) {
      stmt.setString(1, fechaIni);
      stmt.setString(2, fechaFin);
      try (ResultSet rs = stmt.executeQuery()) {
        Map<String, Double> datos = new LinkedHashMap<>();
        boolean resultados = false;
        while (rs.next()) {
          String fecha = rs.getString("Fecha");
          Double total = rs.getDouble("Total");
          datos.put(fecha, total);
          resultados = true;
        }
        if (!resultados) {
          System.out.println("No se encontraron resultados en la cusulta");
        }
        return datos;
      }
    }
  }
  
  private Connection obtenerConexion() throws SQLException {
    return DriverManager.getConnection(url, user, contra);
  }
}
