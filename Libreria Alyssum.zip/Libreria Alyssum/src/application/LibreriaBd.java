package application;



/*
 * Es la responsable de manejar la lista de libros y que impplementa seializable
 * Autor: Rodrigo Slavador
 * Fecha: 13 de octubre de 2024
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
* La clase Libreria gestiona una lista de objetos de tipo Libro.
* Implementa la interfaz Serializable para permitir la serialización
* de la lista de libros.
*/

public class LibreriaBd {
  // Lista de libros que pertenecen a la librería.
  private List<Libro> libros;
  private Libro libro = null;
  private Connection conn;
  private String url = "jdbc:oracle:thin:@//localhost:1521/xe";
  private String user = "System";
  private String contra = "123456";
  private Statement stmt;
  private String consultaLibros;
  private ResultSet resultadoConsulta;
  /** Constructor de la clase Libreria.
  * Inicializa una nueva lista de libros vacía.
  */
  
  public LibreriaBd() {
    this.libros = new ArrayList<Libro>(); // Inicializa la lista vacía.
  }
  /**
  * Método para obtener la lista de libros de la librería.
  * Retorna una nueva lista de libros para evitar modificaciones directas
  * a la lista original. 
  * return una nueva lista que contiene los libros de la librería
  */
  
  public List<Libro> getLibros() {
    // Retorna una copia de la lista de libros.
    return new ArrayList<Libro>(libros);
  }
  /** Método para cargar libros desde un archivo.
  * Lee un archivo serializado y carga los libros en la lista. 
  * archivo la ruta del archivo de donde se cargan los libros
  * throws SQLException 
  * throws IOException            si ocurre un error durante la lectura del archivo
  * throws ClassNotFoundException si la clase no es encontrada durante la deserialización
  */
  
  public List<Libro> cargarLibros() throws SQLException {
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = DriverManager.getConnection(url, user, contra);
      stmt =  conn.createStatement();
      consultaLibros = "SELECT libro.TITULO," 
        + "    libro.ISBN," 
        + "    autor.NOMBRE AS nombre_autor,"  // nombre del autor
        + "    editorial.NOMBRE AS nombre_editorial,"  // nombre de la editorial
        + "    categoria.NOMBRE AS nombre_categoria,"  // nombre de la categoría
        + "    genero.NOMBRE AS nombre_genero,"  // nombre del género
        + "    libro.ANIOPUBLICACION," 
        + "    libro.PRECIO," 
        + "    libro.STOCK," 
        + "    libro.DESCRIPCION "
        + "FROM libro "
        + "JOIN editorial ON libro.ID_EDITORIAL = editorial.ID_EDITORIAL "
        + "JOIN autor ON libro.ID_AUTOR = autor.ID_AUTOR "
        + "JOIN genero ON libro.ID_GENERO = genero.ID_GENERO "
        + "JOIN categoria ON libro.ID_CATEGORIA = categoria.ID_CATEGORIA";
      resultadoConsulta = stmt.executeQuery(consultaLibros);
      while (resultadoConsulta.next()) {
        String titulo = resultadoConsulta.getString("TITULO");
        String isbn = resultadoConsulta.getString("ISBN");
        // Capturamos el nombre del autor
        String nombreAutor  = resultadoConsulta.getString("nombre_autor"); 
        // Capturamos el nombre de la editorial
        String nombreEditorial = resultadoConsulta.getString("nombre_editorial");  
        // Capturamos el nombre de la categoría
        String nombreCategoria = resultadoConsulta.getString("nombre_categoria");
        // Capturamos el nombre del género
        String nombreGenero = resultadoConsulta.getString("nombre_genero");  
        int anioPublicacion = resultadoConsulta.getInt("ANIOPUBLICACION");
        double precio = resultadoConsulta.getDouble("PRECIO");
        int stock = resultadoConsulta.getInt("STOCK");
        String descripcion = resultadoConsulta.getString("DESCRIPCION");
        libro = new Libro(titulo, nombreAutor, isbn, nombreEditorial, 
          nombreCategoria, nombreGenero, anioPublicacion, precio, stock, descripcion);
        libros.add(libro);
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
    return libros;
  }
}
