package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Controlador.
 */
public class Carrito {
  // Lista que contendra los libros agregados al carrito junto con sus cantidades
  private Map<Libro, Integer> librosEnCarrito;
  // Variable para almacenar el total del carrito
  private double total;
  /** constructor que inicializa la lista de libros en el carrito.
  */
  
  public Carrito() {
    this.librosEnCarrito = new HashMap<>();
    this.total = 0;
  }
  /** Metodo para agregar un libro al carrito. 
   *
   * @libro es el libro a guardar.
   */
  
  public void agregarLibro(Libro libro) {
    // Si el libro ya está en el carrito, incrementa la cantidad
    if (librosEnCarrito.containsKey(libro)) {
      incrementaCantdidad(libro);
    } else {
      // Si el libro no está en el carrito, se agrega con una cantidad inicial de 1
      librosEnCarrito.put(libro, 1);
      
    }
  }

  /** Metodo qur incrementa la cantidad de un libro en el carito. 
   * libro a incrementar la cantidad
   */  
  public void incrementaCantdidad(Libro libro) {
    // Incrementa la cantidad del libro en el carrito
    int cantidadActual = librosEnCarrito.get(libro);
    librosEnCarrito.put(libro, cantidadActual + 1);
  }
  /** Metodoo para eliminar un libro del carrito. 
   * libro para eliminar
   */
  
  public void eliminarLibro(Libro libro) {
    // Elimina el libro del carrito si lo encuentra
    librosEnCarrito.remove(libro);
  }
  /** Eliminar la catidad de un libro.
   * libro libro a disminuir su cantidad
   */
  
  public void eliminarCantidad(Libro libro) {
    if (librosEnCarrito.containsKey(libro)) {
      librosEnCarrito.put(libro, librosEnCarrito.get(libro) - 1);
    }
  }
  /** Metodo que regresa la lista de libros en el carrito. 
   * return regresa la lista
   */
  
  public List<Libro> getLibrosEnCarrito() {
    return new ArrayList<Libro>(librosEnCarrito.keySet());
  }
  /** Metodo para mostrar los libros del carrito.
   */
  
  public void mostrarCarrito() {
    for (Map.Entry<Libro, Integer> entry : librosEnCarrito.entrySet()) {
      Libro libro = entry.getKey();
      Integer cantidad = entry.getValue();
      System.out.println(libro.getTitulo() + " x " + cantidad);
    }
  }
  /** Metodo para calcular el total del carrito sumando los precios de los libros. 
   * return el total del carrito
   */
  
  public double calcularTotal() {
    total = 0;
    for (Map.Entry<Libro, Integer> entry : librosEnCarrito.entrySet()) {
      Libro libro = entry.getKey();
      Integer cantidad = entry.getValue();
      total += libro.getPrecio() * cantidad;
    }
    return total;
  }
  /** Metodo que regresa el numero total de libros en el carrito. 
   * return el total de libros en el carrito
   */
  
  public int obtenerTotalLibros() {
    int cant = 0;
    // Suma la cantidad de todos los libros del carrito
    for (Integer cantidad : librosEnCarrito.values()) {
      cant += cantidad;
    }
    return cant;
  }
  /** Método para obtener la cantidad de un libro específico en el carrito.
   * libro Libro del cual se quiere obtener la cantidad.
   * return Cantidad de ejemplares en el carrito
   */
  
  public int getCantidadLibro(Libro libro) {
    return librosEnCarrito.getOrDefault(libro, 0);
  }
}
