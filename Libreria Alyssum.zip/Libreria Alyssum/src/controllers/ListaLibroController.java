/**
 * Controlador para la pantalla Inicio.
 * Esta clase maneja la lógica de la interfaz de usuario 
 * para permitir a los clientes ver la lista de libros
 * y poder hacer una busqueda de ellos
 * Autor: Rodrigo Slavador
 * Fecha: 12 de octubre de 2024
 */

package controllers;

import application.Carrito;
import application.LibreriaBd;
import application.Libro;
import java.sql.SQLException;
import java.text.Normalizer;
import java.util.List;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * Clase ListaLibroController.
 * Esta clase controla la interfaz gráfica relacionada con la lista de libros,
 * permitiendo mostrar, filtrar y buscar libros
 * También gestiona la carga inicial de libros y el comportamiento de los controles.
 */

public class ListaLibroController {
  @FXML
  private Button verTodos; // Boton para a mostar la lista de libros en la tabla
  @FXML
  private CheckBox checkSoloDisponibles; // CheckBox para solo mostrar libros con stock > 0
  // Campo de texto para ingresar el autor del libro a buscar.
  @FXML
  private TextField autor;
  // Imagenes que sirven como banners en la interfaz gráfica.
  @FXML
  private ImageView banner1; 
  @FXML
  private ImageView banner2;
  @FXML
  private ImageView banner3;
  @FXML
  private CheckBox soloDisponibles;
  // Imagen para mostrar una miniatura en la interfaz gráfica.
  @FXML
  private ImageView cartaImagne;
  // ComboBox para seleccionar la categoría del libro.
  @FXML
  private ComboBox<String> categoria;
  // Columnas de la tabla donde se mostrarán los libros.
  @FXML
  private TableColumn<Libro, HBox> columnaAcciones; // Columna de acciones (vacía por ahora).
  @FXML
  private TableColumn<Libro, String> columnaAutor; // Columna para mostrar el autor del libro.
  //Columna para mostrar la editorial del libro.
  @FXML
  private TableColumn<Libro, String> columnaEditorial; 
  @FXML
  private TableColumn<Libro, Double> columnaPrecio; // Columna para mostrar el precio del libro.
  @FXML
  private TableColumn<Libro, Integer> columnaStock; // Columna para mostrar el stock disponible.
  @FXML
  private TableColumn<Libro, String> columnaTitulo; // Columna para mostrar el título del libro.
  // Campo de texto para ingresar la editorial del libro a buscar.
  @FXML
  private TextField editorial;
  // Slider para filtrar libros por precio.
  @FXML
  private Slider sliderPrecio;
  // Tabla para mostrar la lista de libros.
  @FXML
  private TableView<Libro> tablaDeLibros;
  // Campo de texto para ingresar el título del libro a buscar.
  @FXML
  private TextField titulo;
  // Etiqueta para mostrar el valor seleccionado del slider de precio.
  @FXML
  private Label valor;
  @FXML
  private Label librosCarrito;
  // Instancia de Libreria que almacena la lista de libros.
  private LibreriaBd libreriaBd;
  // Lista observable para conectar con la tabla de libros en la interfaz gráfica.
  private ObservableList<Libro> listaLibros = FXCollections.observableArrayList();
  // Indice de la imagen actual que se muestra en el banner
  private int indiceImagen = 0; 
  private int indice2 = 5;  
  private int indice3 = 2;  
  private int tiempo = 5; // Tiempo en segundos para la rotacion
  // Variable para almacenar el libro seleccionado en la tabla
  private Libro libroSeleccionado;
  // Instancia se la clase carrito que gestiona los libros añadidos al carrito de compras
  private Carrito carrito =  new Carrito();
  //Lista de imagenes que se mostraran en el banner
  private List<Image> imagenesBanner = List.of(
    new Image(getClass().getResourceAsStream("/images/libro1.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro2.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro3.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro4.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro5.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro6.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro7.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro8.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro9.jpg")),
    new Image(getClass().getResourceAsStream("/images/libro10.jpg"))
    );
  /**
  * Método initialize.
  * Este método se ejecuta automáticamente al inicializar la vista.
  * Carga los libros de un archivo y configura la tabla de libros.
  */
  
  @FXML
  public void initialize() {
    libreriaBd = new LibreriaBd(); // Crea una nueva instancia de la librería.
    try {
      listaLibros.addAll(libreriaBd.cargarLibros());
    } catch (SQLException e) {
      e.printStackTrace();
    }
    tablaDeLibros.setItems(listaLibros); // Establece los libros en la tabla.
    cargarComboBox();
    configurarColumnas(); // Configura cómo se mostrarán los datos en las columnas.
    cargarBanner();
    iniciarRotacion();
    // Añade un listener al slider de precio para actualizar el valor visualmente.
    sliderPrecio.valueProperty().addListener((observable, oldValue, newValue) -> {
      Double costo1 = newValue.doubleValue(); // Obtiene el valor seleccionado en el slider.
      String costo =  String.format("%.2f", costo1); // Formatea el valor como precio.
      valor.setText("$" + costo); // Actualiza la etiqueta para mostrar el precio seleccionado.
    });
  }
  // Metodo para inicializar el comboBox
  
  private void cargarComboBox() {
    categoria.getItems().addAll("Ficcion", "No Ficcion", "Infantil", "Ciencia y Tecnologia");
  }
  
  /*
  * Inicia la rotacion de las imagenes del banner
  * Las imagenes cambian cada tiempo en segundos
  */
  
  private void iniciarRotacion() {
    // Cambiar la imagen del banner cada tiempo en segundos
    Timeline timeline = new Timeline(
        new KeyFrame(Duration.seconds(tiempo), event -> cambiarBanner())); 
    timeline.setCycleCount(Timeline.INDEFINITE); //Repetir indefinidamente
    timeline.play(); // Iniciar la animacion
  }
  /**
  * Cambia la imagen del banner a la siguiente en la lista
  * si se llega al final de la lista, vuelve al inicio.
  */
  
  private void cambiarBanner() {
    indiceImagen = (indiceImagen + 1) % imagenesBanner.size(); // Actualizar el indice de la imagen
    indice2 = (indice2 + 1) % imagenesBanner.size();
    indice3 = (indice3 + 1) % imagenesBanner.size();
    cargarBanner(); // Cargar la nueva imagen del banner
  }
  /*
  * Cargar la imagen actual del banner en el imageView
  */
  
  private void cargarBanner() {
    banner1.setImage(imagenesBanner.get(indiceImagen)); // Establecer la imagen del banner
    banner2.setImage(imagenesBanner.get(indice2));
    banner3.setImage(imagenesBanner.get(indice3));
  }
  /**
  * Método para configurar las columnas de la tabla.
  * Establece cómo se deben mostrar los atributos de cada libro en las columnas correspondientes.
  */
  
  private void configurarColumnas() {
    // Configura la columna del título para que muestre el valor de getTitulo() del objeto Libro.
    columnaTitulo.setCellValueFactory(
        celData -> new SimpleStringProperty(celData.getValue().getTitulo()));
    // Configura la columna del autor para que muestre el valor de getAutor() del objeto Libro.
    columnaAutor.setCellValueFactory(
        celData -> new SimpleStringProperty(celData.getValue().getAutor()));
    // Configura la columna de la editorial para que muestre el valor de editorial del objeto Libro.
    columnaEditorial.setCellValueFactory(
        celData -> new SimpleStringProperty(celData.getValue().getEditorial()));
    // Configura la columna del precio para que muestre el valor de Precio del objeto Libro.
    columnaPrecio.setCellValueFactory(
        celData -> new SimpleDoubleProperty(celData.getValue().getPrecio()).asObject());
    // Configura la columna del stock para que muestre el valor de Stock del objeto Libro.
    columnaStock.setCellValueFactory(
        celData -> new SimpleIntegerProperty(celData.getValue().getStock()).asObject());
    //Configura la columna de acciones para meter los botones necesarios
    configurarColumnaAcciones();
  }
    
  private void configurarColumnaAcciones() {
    //Configuracion de la columna acciones para cada libro
    columnaAcciones.setCellFactory(columnaAcciones -> {
      return new TableCell<Libro, HBox>() {
        // cree un boton agregar para cada fila de la tabla
        private final Button btnAgregar = new Button("Agregar");
        // cree un Hbox para contener dos botones pero de momento el mas importante es el de agregar
        private final HBox hbox = new HBox(10, btnAgregar);
        {
          // Aplico la clase de estilo que tengo para todos lo votones
          btnAgregar.getStyleClass().add("bottones2");
          //Accion que se ejecuta cuando se hace clicc en el boton agregar
          btnAgregar.setOnAction(eventHandler -> {
            // Obtengo el libro de la fila correspondiente
            libroSeleccionado = getTableView().getItems().get(getIndex());
            if (libroSeleccionado.getStock() > 0) {
              // Agrego el libro al carrito
              carrito.agregarLibro(libroSeleccionado);
              libroSeleccionado.setStock(libroSeleccionado.getStock() - 1);
              // Actualizo la acntidad de libro en el carrito del label carrito
              librosCarrito.setText(carrito.obtenerTotalLibros() + "");
              getTableView().refresh();
            } else {
              //A lerta para informar que no hay stock disponible del libro que eligio
              Alert alert = new 
                  Alert(Alert.AlertType.WARNING, "No hay "
                    + "stock disponible para este libro.");
              alert.showAndWait(); // Muestra la alerta
            }
          });
        }
        //Sobrescribi el metodo updateItem para controlar la viaualizacion de la celda 
  
        @Override
  protected void updateItem(HBox item, boolean res) {
          // Llamo al metodo de la superclase para mantener el cpmportamiento
          super.updateItem(item, res);
          // Es para verificar si la celda esta vacia o no
          if (res) {
            // Si la celda esta vacia, no muestra el hbox
            setGraphic(null);
          } else {
            // si la celda no esta vacia muestro el hbox que contiene el boton
            setGraphic(hbox);
          }
        }
      };
    });
  }

  // Métodos vacíos para los botones que filtran por genero.
  @FXML
  void btnEducacion(ActionEvent event) {
    // Lista observable para poder filtara de la principal
    ObservableList<Libro> librosEducacion = FXCollections.observableArrayList();
    for (Libro libro : listaLibros) {
      // Metodo para validar que el genero sea el elegido
      if ("educacion".equalsIgnoreCase(normalizarTexto(libro.getGenero()))) {
        // Agrega a la lista los libros que coincidad con el genero
        librosEducacion.add(libro);
      }
    }
    tablaDeLibros.setItems(librosEducacion);
    configurarColumnaAcciones();
  }

  @FXML
  void btnRomance(ActionEvent event) {
    // Lista observable para poder filtara de la principal
    ObservableList<Libro> librosRomance = FXCollections.observableArrayList();
    for (Libro libro : listaLibros) {
      if ("romance".equalsIgnoreCase(normalizarTexto(libro.getGenero()))) {
        librosRomance.add(libro);
      }
    }
    tablaDeLibros.setItems(librosRomance);
    configurarColumnaAcciones();
  }

  @FXML
  void btnFantasia(ActionEvent event) {
    ObservableList<Libro> librosFantasia = FXCollections.observableArrayList();
    for (Libro libro : listaLibros) {
      if ("fantasia".equalsIgnoreCase(normalizarTexto(libro.getGenero()))) {
        librosFantasia.add(libro);
      }
    }
    tablaDeLibros.setItems(librosFantasia);
    configurarColumnaAcciones();
  }

  @FXML
  private void buscarLibro(ActionEvent event) {
    /* Obtengo los valores ingresados o seleccionados en los campos de búsqueda:
    * Obtiene el texto ingresado en el campo de búsqueda de título, 
    * eliminando espacios en blanco al inicio y al final 
    * y convirtiendo todo a minúsculas para hacer la búsqueda insensible a mayúsculas/minúsculas
    */
    String tituloBuscado = titulo.getText().trim().toLowerCase();
    // texto del campo de autor, eliminando espacios y convirtiendo a minúsculas.
    String autorBuscado = autor.getText().trim().toLowerCase();
    // Obtiene el texto ingresado en el campo ISBN, sin modificarlo.
    String editorialBuscado = editorial.getText().trim().toLowerCase();
    /* Verifica si se ha seleccionado una categoría en el combo box, y si es así, 
    * elimina espacios y normaliza el texto
    * (es decir, elimina tildes y convierte a minúsculas). 
    * Si no se selecciona ninguna categoría, devuelve `null`.
    */
    String categoriaSeleccionada = categoria.getValue() != null ? normalizarTexto(
        categoria.getValue().trim()) : null;
    // Obtiene el valor del slider de precio, que será utilizado como precio máximo en la búsqueda.
    double precioMaximo = sliderPrecio.getValue();
    // Filtra la lista de libros según los criterios de búsqueda ingresados por el usuario.
    ObservableList<Libro> librosFiltrados = listaLibros.filtered(libro -> {
      /* Verifica si hay coincidencia para cada campo de búsqueda o 
      * si el criterio se omite (porque está vacío).
      * Filtra por título: Si el campo de título está vacío, 
      * se considera que coincide con cualquier libro.
      * Si no está vacío, verifica si el título del libro 
      * contiene el texto buscado (insensible a mayúsculas).
      */
      boolean coincideTitulo = tituloBuscado.isEmpty() 
          || libro.getTitulo().toLowerCase().contains(tituloBuscado);
      boolean coincideAutor = autorBuscado.isEmpty() 
          || libro.getAutor().toLowerCase().contains(autorBuscado);
      boolean coincideEditorial = editorialBuscado.isEmpty() 
          || libro.getEditorial().toLowerCase().contains(editorialBuscado);
      String categoriaLibro = normalizarTexto(libro.getCategoria().trim());
      boolean coincideCategoria = (categoriaSeleccionada == null 
          || categoriaSeleccionada.equals(categoriaLibro));
      boolean coincidePrecio = precioMaximo == 0 || libro.getPrecio() <= precioMaximo;      
      boolean coincideDisponibilidad = !soloDisponibles.isSelected() || libro.getStock() > 0;      
      return coincideTitulo && coincideAutor && coincideEditorial 
        && coincideCategoria && coincidePrecio && coincideDisponibilidad;
    });
    /* Si la lista filtrada de libros está vacía, 
     * imprime un mensaje indicando que no se encontraron resultados.
     */
    if (librosFiltrados.isEmpty()) {
      Alert alerta = new Alert(AlertType.INFORMATION, 
          "No se encontraron libros que coincidan con los criterios.");
      alerta.showAndWait();
      return;
    }
    /* Establece la lista filtrada en la tabla de libros
     *  para mostrar solo los libros que coinciden con los criterios.
     */
    tablaDeLibros.setItems(librosFiltrados);
  }
  // Función para normalizar cadenas (eliminar tildes y convertir a minúsculas)
  
  private String normalizarTexto(String texto) {
    // Verifica si el texto es nulo
    if (texto == null) {
      return null; // Si el texto es nulo, retornamos null
    }
    /* Normalizar el texto utilizando Normalizer
    * Normalizer.normalize() descompone los caracteres especiales 
    * (como letras con tildes) en una forma base
    * Form.NFD descompone los caracteres con tildes en una letra base 
    * y el símbolo de la tilde por separado
    */
    String textoNormalizado = Normalizer.normalize(texto, Normalizer.Form.NFD);
    /* Reemplazar cualquier carácter diacrítico (como las tildes) con una cadena vacía
    * Elimina los caracteres combinados
    * dejando solo las letras básicas (por ejemplo, 'é' se convierte en 'e')
    * Luego, pasamos todo el texto a minúsculas 
    * con toLowerCase() para evitar problemas de mayúsculas/minúsculas al comparar
    */
    return textoNormalizado.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "").toLowerCase();
  }
  
  @FXML
  private void limpiarFiltros(ActionEvent event) {
    //Limpiar los campos de texto de busqueda
    titulo.clear();
    autor.clear();
    editorial.clear();
    // Restablece el ComboBox de categoria
    // clearDelection() eliminal la seleciion actual del comboBox
    categoria.getSelectionModel().clearSelection();
    // Restablece el slider de precio al valor minimo
    sliderPrecio.setValue(sliderPrecio.getMin());
    // Desmarca el checkBox de "Solo disponibles"
    soloDisponibles.setSelected(false);
    // Restablece la tabla con la lista completa de libros
    tablaDeLibros.setItems(listaLibros);
    configurarColumnaAcciones();
  }
  // metodo para refrescar la tabla
  
  @FXML
  void btnVerTodos(ActionEvent event) {
    // Restablece la tabla con la lista completa de libros
    tablaDeLibros.setItems(listaLibros);
    configurarColumnaAcciones();
  }
  
  @FXML
  void oneClickCarrito(MouseEvent event) {
    if (carrito.obtenerTotalLibros() == 0) {
      Alert aler = new Alert(Alert.AlertType.INFORMATION,
              "Tu carrito esta vacio, agrega libros para poder visualizar tus compras");
      aler.showAndWait();
    } else {
      Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Carrito.fxml"));
        VBox root = loader.load();
        CarritoControler carritoControlador = loader.getController();
        carritoControlador.setCarrito(carrito);
        Stage primStage = new Stage();
        Scene scene  = new Scene(root, 1000, 800);
        scene.getStylesheets().add(
            getClass().getResource("/fxml/application.css").toExternalForm());
        primStage.setScene(scene);
        primStage.show();
        stage.close();
      } catch (Exception e) {
        System.out.println(e.getMessage());
      }
    }
  }
}