package controllers;


import java.util.Optional;

import application.Carrito;
import application.Libro;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
/** Controlador para la intefaz de carrito.
 */

public class CarritoControler {
  @FXML
  private Label cantidadLibros;
 
  @FXML
  private TableColumn<Libro, HBox> columnaAcciones;

  @FXML
  private TableColumn<Libro, Integer> columnaCantidad;

  @FXML
  private TableColumn<Libro, String> columnaLibro;

  @FXML
  private TableColumn<Libro, Double> columnaPrecio;

  @FXML
  private TableColumn<Libro, Double> columnaTotal;

  @FXML
  private ImageView img1;

  @FXML
  private ImageView img2;

  @FXML
  private ImageView img3;

  @FXML
  private Label labelIva;

  @FXML
  private Label labelSubTotal;

  @FXML
  private Label labelTotal;

  @FXML
  private TableView<Libro> tablaCarrito;
  
  private Carrito carrito;  // Referencia al carrito para obtener la cantidad y calcular el total
  
  private ObservableList<Libro> librosEnCarrito = FXCollections.observableArrayList();
  /** Metodo para pasar la listda de libros de una interfa a otra.
  */
  
  public void setCarrito(Carrito carr) {
    carr.mostrarCarrito();
    this.carrito = carr;
    librosEnCarrito.addAll(carr.getLibrosEnCarrito());
    tablaCarrito.setItems(librosEnCarrito);
    configurarInicio();
  }
  /** Configurar todo.
   */
  
  public void configurarInicio() {
    configurarColumnas();
    double total = carrito.calcularTotal();
    double iva = carrito.calcularTotal() * 0.16;
    labelSubTotal.setText("$" + total);
    labelIva.setText("$" + iva);
    labelTotal.setText("$" + (total + iva));
    cantidadLibros.setText(carrito.obtenerTotalLibros() + " pz.");
  }
  
  private void configurarColumnas() {
    columnaLibro.setCellValueFactory(data -> {
      return new SimpleStringProperty(data.getValue().getTitulo()
       + "\nDe:" + data.getValue().getAutor());
    });
    columnaCantidad.setCellValueFactory(data -> {
      int cantidad = carrito.getCantidadLibro(data.getValue());
      return new SimpleIntegerProperty(cantidad).asObject();
    });
    columnaPrecio.setCellValueFactory(data -> {
      return new SimpleDoubleProperty(data.getValue().getPrecio()).asObject();
    });
    columnaTotal.setCellValueFactory(data -> {
      int cantidad = carrito.getCantidadLibro(data.getValue());
      double total = data.getValue().getPrecio() * cantidad;
      return new SimpleDoubleProperty(total).asObject();
    });
    configurarColumnaAcciones();
  }
  
  private void configurarColumnaAcciones() {
    //Configuracion de la columna acciones para cada libro
    columnaAcciones.setCellFactory(columnaAcciones -> {
      return new TableCell<Libro, HBox>() {
        // cree un boton agregar para cada fila de la tabla
        private final Button btnAumentar = new Button("+");
        private final Button btnDisminuir = new Button("-");
        private final Button btnEliminar = new Button("Eliminar");
        // cree un Hbox para contener dos botones pero de momento el mas importante es el de agregar
        private final HBox hbox = new HBox(10, btnAumentar, btnDisminuir, btnEliminar); {
          // Aplico la clase de estilo que tengo para todos lo votones
          btnAumentar.getStyleClass().add("bottones2");
          btnDisminuir.getStyleClass().add("bottones2");
          btnEliminar.getStyleClass().add("bottones2");
          
          //Accion que se ejecuta cuando se hace clicc en el boton agregar
          btnAumentar.setOnAction(eventHandler -> {
            Libro lib = getTableView().getItems().get(getIndex());
            carrito.agregarLibro(lib);
            configurarInicio();
          });
          btnDisminuir.setOnAction(eventHandler -> {
            Libro lib = getTableView().getItems().get(getIndex());
            if (carrito.getCantidadLibro(lib) > 1) {
              carrito.eliminarCantidad(lib);
              configurarInicio();
            } else {
              Alert alert = new Alert(
                  Alert.AlertType.CONFIRMATION, "¿Deseas eliminar el libro de tu carrito?");
              Optional<ButtonType> resultado = alert.showAndWait();
              if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
                carrito.eliminarLibro(lib);
                librosEnCarrito.remove(lib);
                if (carrito.obtenerTotalLibros() == 0) {
                  Alert alerta = new Alert(Alert.AlertType.INFORMATION, 
                      "Carrito vacio, regresando a la lista de libros");
                  alerta.showAndWait();
                  btnVerLista(eventHandler);
                } else {
                  configurarInicio();
                }
              }
            }
          });
        }
    
        @Override
    protected void updateItem(HBox item, boolean res) {
          // Llamo al metodo de la superclase para mantener el comportamiento
          super.updateItem(item, res);
          // Es para verificar si la celda esta vacia o no
          if (res) {
            // Si la celda esta vacia, no muestra el hbox
            setGraphic(null);
          } else {
            // si la celda no esta vacia muestro el hbox que contiene los botones
            setGraphic(hbox);
          }
        }
      };
    });
  }
  
  /** Metodo para pasar a hacer el pago.
   */

  @FXML
  public void btnConfirmar(ActionEvent event) {

  }
  /** Regresar a la interfaz anterior.
   */
  
  @FXML
  public void btnVerLista(ActionEvent event) {

  }
  
  

}
