module LibreriaAlyssum {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires java.sql;
	requires javafx.graphics;
	
	opens application to javafx.graphics, javafx.fxml, javafx.base, javafx.controls;
	opens controllers to javafx.graphics, javafx.fxml, javafx.base, javafx.controls;
}
